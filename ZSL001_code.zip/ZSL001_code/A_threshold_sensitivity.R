# ZSL001 - A threshold sensitivity analysis

library(tidyverse)

data_folder <- "~/Desktop/A all"

csv_files <- list.files(
  path = "~/Desktop/A all",
  pattern = "^ZSL001_A1_raw_.*\\.csv$",
  full.names = TRUE
)

length(csv_files)
stopifnot(length(csv_files) == 28)

all_data <- csv_files |>
  map_dfr(read_csv, show_col_types = FALSE)

n_distinct(all_data$site_id)
stopifnot(n_distinct(all_data$site_id) == 28)

thresholds <- c(0.5, 0.7, 0.8, 0.9)

minimum_valid_months <- 3

threshold_results <- map_dfr(
  thresholds,
  function(current_threshold) {
    
    retained_months <- all_data |>
      filter(
        valid_coverage_fraction >= current_threshold,
        !is.na(water_fraction_of_valid_area)
      )
    
    annual_results <- retained_months |>
      group_by(site_id, year) |>
      summarise(
        valid_month_count = n(),
        annual_mean_water_fraction =
          mean(water_fraction_of_valid_area),
        .groups = "drop"
      ) |>
      filter(valid_month_count >= minimum_valid_months)
    
    annual_results |>
      group_by(site_id) |>
      summarise(
        valid_year_count = n(),
        .groups = "drop"
      ) |>
      mutate(threshold = current_threshold)
  }
)

print(threshold_results)

threshold_summary <- threshold_results |>
  group_by(threshold) |>
  summarise(
    sites_retained = n_distinct(site_id),
    median_valid_years = median(valid_year_count),
    minimum_valid_years = min(valid_year_count),
    maximum_valid_years = max(valid_year_count),
    sites_with_15_or_more_years =
      sum(valid_year_count >= 15),
    sites_with_20_or_more_years =
      sum(valid_year_count >= 20),
    .groups = "drop"
  )

print(threshold_summary)

# Two-level threshold sensitivity analysis

monthly_coverage_thresholds <- c(0.5, 0.7, 0.8, 0.9)
annual_month_fraction_thresholds <- c(0.5, 0.6, 0.7, 0.8)

site_window_lengths <- all_data |>
  group_by(site_id) |>
  summarise(
    expected_months = n_distinct(month),
    .groups = "drop"
  )

two_level_results <- crossing(
  monthly_coverage_threshold = monthly_coverage_thresholds,
  annual_month_fraction = annual_month_fraction_thresholds
) |>
  pmap_dfr(
    function(monthly_coverage_threshold,
             annual_month_fraction) {
      
      retained_months <- all_data |>
        filter(
          valid_coverage_fraction >= monthly_coverage_threshold,
          !is.na(water_fraction_of_valid_area)
        )
      
      annual_results <- retained_months |>
        group_by(site_id, year) |>
        summarise(
          valid_month_count = n(),
          annual_mean_water_fraction =
            mean(water_fraction_of_valid_area),
          .groups = "drop"
        ) |>
        left_join(
          site_window_lengths,
          by = "site_id"
        ) |>
        mutate(
          required_month_count =
            ceiling(expected_months * annual_month_fraction)
        ) |>
        filter(
          valid_month_count >= required_month_count
        )
      
      annual_results |>
        group_by(site_id) |>
        summarise(
          valid_year_count = n(),
          .groups = "drop"
        ) |>
        mutate(
          monthly_coverage_threshold =
            monthly_coverage_threshold,
          annual_month_fraction =
            annual_month_fraction
        )
    }
  )

print(two_level_results)

two_level_summary <- two_level_results |>
  group_by(
    monthly_coverage_threshold,
    annual_month_fraction
  ) |>
  summarise(
    sites_retained = n_distinct(site_id),
    median_valid_years = median(valid_year_count),
    minimum_valid_years = min(valid_year_count),
    maximum_valid_years = max(valid_year_count),
    sites_with_15_or_more_years =
      sum(valid_year_count >= 15),
    sites_with_20_or_more_years =
      sum(valid_year_count >= 20),
    .groups = "drop"
  ) |>
  arrange(
    monthly_coverage_threshold,
    annual_month_fraction
  )

print(two_level_summary, n = Inf)

appendix_threshold_table <- two_level_summary |>
  transmute(
    `Monthly spatial coverage threshold (%)` =
      monthly_coverage_threshold * 100,
    
    `Required breeding-window months per year (%)` =
      annual_month_fraction * 100,
    
    `Reference sites retained` =
      sites_retained,
    
    `Median valid years per site` =
      median_valid_years,
    
    `Minimum valid years for any site` =
      minimum_valid_years,
    
    `Maximum valid years for any site` =
      maximum_valid_years,
    
    `Sites with at least 15 valid years` =
      sites_with_15_or_more_years,
    
    `Sites with at least 20 valid years` =
      sites_with_20_or_more_years
  )

write_csv(
  appendix_threshold_table,
  file.path(data_folder, "Appendix_A_threshold_sensitivity.csv")
)

print(appendix_threshold_table, n = Inf)

# Apply site-specific analysis start years

all_data_final <- all_data |>
  filter(
    !(site_id == "GRC_Karl" & year < 2011),
    !(site_id == "IRN_SivaDam" & year < 2008)
  )

all_data_final |>
  filter(site_id %in% c("GRC_Karl", "IRN_SivaDam")) |>
  group_by(site_id) |>
  summarise(
    first_year = min(year),
    last_year = max(year),
    rows_remaining = n(),
    .groups = "drop"
  ) |>
  print()
