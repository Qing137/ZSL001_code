// ZSL001 — B class: monthly diagnostic table, batch 2
// Exports one task per site.

var standardSites = ee.FeatureCollection(
  'projects/airrun-494212/assets/ZSL001_standard_sites'
);
var complexSites = ee.FeatureCollection(
  'projects/airrun-494212/assets/ZSL001_complex_sites'
);
var allSites = standardSites.merge(complexSites);

var breedingWindows = {
  'BGR_SrebLake': [2, 6],
  'ALB_Kara': [1, 7],
  'RUS_CherLake': [4, 8],
  'TUR_BuyuMend': [2, 7],
  'TUR_GediDelt': [2, 7],
  'MNG_AiraLake': [6, 9],
  'RUS_ManyLake': [4, 8],
  'GRC_AmvrWetl': [2, 6],
  'IRN_Bakh': [3, 7],
  'MNG_KharUs': [6, 9]
};

var years = [2019, 2020, 2021, 2022, 2023, 2024, 2025];

var S2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED');

var emptyNdci = ee.Image.constant(0)
  .rename('NDCI')
  .updateMask(ee.Image.constant(0));

function getSiteProjection(geom) {
  return ee.Image(
    S2.filterDate('2019-01-01', '2026-01-01')
      .filterBounds(geom)
      .sort('system:time_start')
      .first()
  ).select('B5').projection();
}

function computeMonthlyDiagnostic(siteId, geom, polygonAreaKm2, siteProjection, year, month) {
  var monthStart = ee.Date.fromYMD(year, month, 1);
  var monthEnd = monthStart.advance(1, 'month');

  var monthCollection = S2
    .filterDate(monthStart, monthEnd)
    .filterBounds(geom)
    .select(['B4', 'B5', 'SCL']);

  var rawGranuleCount = monthCollection.size();

  var dateStrings = monthCollection
    .aggregate_array('system:time_start')
    .map(function(t) { return ee.Date(t).format('YYYY-MM-dd'); })
    .distinct();

  var acquisitionDayCount = dateStrings.size();

  var dailyNdciImages = dateStrings.map(function(dateStr) {
    dateStr = ee.String(dateStr);
    var dayStart = ee.Date.parse('YYYY-MM-dd', dateStr);
    var dayEnd = dayStart.advance(1, 'day');

    var dayCollection = monthCollection
      .filterDate(dayStart, dayEnd)
      .sort('system:index');

    var waterBands = dayCollection.map(function(image) {
      return image.select(['B4', 'B5']).updateMask(image.select('SCL').eq(6));
    }).mosaic();

    var red = waterBands.select('B4');
    var redEdge = waterBands.select('B5');
    var denominator = redEdge.add(red);

    return redEdge.subtract(red)
      .divide(denominator)
      .rename('NDCI')
      .updateMask(denominator.neq(0))
      .set('system:index', dateStr);
  });

  var dailyCollection = ee.ImageCollection.fromImages(dailyNdciImages)
    .merge(ee.ImageCollection([emptyNdci.set('system:index', 'empty')]));

  var monthlyNdciImage = dailyCollection.median().rename('NDCI');

  var areaBand = ee.Image.pixelArea()
    .rename('AREA_M2')
    .updateMask(monthlyNdciImage.mask());

  var analysisImage = monthlyNdciImage.addBands(areaBand);

  var combinedReducer = ee.Reducer.percentile([25, 50, 75])
    .combine({ reducer2: ee.Reducer.count(), sharedInputs: true })
    .combine({ reducer2: ee.Reducer.sum(), sharedInputs: true });

  var stats = ee.Dictionary(
    analysisImage.reduceRegion({
      reducer: combinedReducer,
      geometry: geom,
      crs: siteProjection,
      scale: 20,
      maxPixels: 1e10,
      tileScale: 16
    })
  );

  var footprintPixelCount = ee.Number(stats.get('NDCI_count', 0));
  var footprintAreaKm2 = ee.Number(stats.get('AREA_M2_sum', 0)).divide(1e6);

  var footprintFraction = ee.Algorithms.If(
    footprintPixelCount.gt(0),
    footprintAreaKm2.divide(polygonAreaKm2),
    null
  );

  var status = ee.Algorithms.If(
    rawGranuleCount.eq(0), 'NO_IMAGE',
    ee.Algorithms.If(footprintPixelCount.eq(0), 'NO_DETECTED_WATER', 'OK')
  );

  return ee.Feature(null, {
    site_id: siteId,
    year: year,
    month: month,
    polygon_area_km2: polygonAreaKm2,
    raw_granule_count: rawGranuleCount,
    acquisition_day_count: acquisitionDayCount,
    monthly_observed_water_footprint_pixel_count: footprintPixelCount,
    monthly_observed_water_footprint_area_km2: footprintAreaKm2,
    monthly_observed_water_footprint_fraction: footprintFraction,
    monthly_ndci_median: stats.get('NDCI_p50', null),
    monthly_ndci_spatial_p25: stats.get('NDCI_p25', null),
    monthly_ndci_spatial_p75: stats.get('NDCI_p75', null),
    status: status
  });
}

print(
  'Missing site IDs:',
  ee.List(Object.keys(breedingWindows)).removeAll(
    ee.List(allSites.aggregate_array('site_id'))
  )
);

// Batch 2, one export task per site 
Object.keys(breedingWindows).forEach(function(siteId) {
  var siteFeature = ee.Feature(
    allSites.filter(ee.Filter.eq('site_id', siteId)).first()
  );
  var geom = siteFeature.geometry();
  var polygonAreaKm2 = geom.area(30).divide(1e6);
  var siteProjection = getSiteProjection(geom);

  var window = breedingWindows[siteId];
  var startMonth = window[0];
  var endMonth = window[1];

  var siteResults = [];

  years.forEach(function(year) {
    for (var month = startMonth; month <= endMonth; month++) {
      siteResults.push(
        computeMonthlyDiagnostic(siteId, geom, polygonAreaKm2, siteProjection, year, month)
      );
    }
  });

  var siteTable = ee.FeatureCollection(siteResults);

  Export.table.toDrive({
    collection: siteTable,
    description: 'ZSL001_B_monthly_diagnostic_' + siteId,
    fileNamePrefix: 'ZSL001_B_monthly_diagnostic_' + siteId,
    fileFormat: 'CSV'
  });
});
