# ZSL001 B class
# 28 reference sites: final site-level NDCI

library(tidyverse)

b_zip <- file.choose()

temp_dir <- tempfile()

dir.create(temp_dir)

unzip(
  b_zip,
  exdir = temp_dir
)

b_files <- list.files(
  temp_dir,
  pattern = "^ZSL001_B_monthly_diagnostic_.*\\.csv$",
  full.names = TRUE,
  recursive = TRUE
)

b_data <- map_dfr(
  b_files,
  read_csv,
  show_col_types = FALSE
)

# Check 28 reference sites
if (n_distinct(b_data$site_id) != 28) {
  stop("The dataset does not contain exactly 28 reference sites.")
}

# Check duplicate site-year-month records
duplicate_rows <- b_data |>
  count(site_id, year, month) |>
  filter(n > 1)

if (nrow(duplicate_rows) > 0) {
  print(duplicate_rows, n = Inf)
  stop("Duplicate site-year-month records were found.")
}

# Keep all sites from the input data
all_sites <- b_data |>
  distinct(site_id)

# Determine the expected number of breeding-window months for each site
site_window_lengths <- b_data |>
  group_by(site_id) |>
  summarise(
    expected_months = n_distinct(month),
    .groups = "drop"
  )

# Fixed monthly QC
valid_months <- b_data |>
  filter(
    status == "OK",
    !is.na(monthly_ndci_median)
  )

# Monthly -> annual median using the 50% completeness rule
annual_data <- valid_months |>
  group_by(site_id, year) |>
  summarise(
    valid_month_count = n(),
    annual_ndci =
      median(monthly_ndci_median),
    .groups = "drop"
  ) |>
  left_join(
    site_window_lengths,
    by = "site_id"
  ) |>
  mutate(
    required_month_count =
      ceiling(expected_months * 0.5)
  ) |>
  filter(
    valid_month_count >= required_month_count
  )

# Annual -> final site median
site_level_core <- annual_data |>
  group_by(site_id) |>
  summarise(
    valid_years = n(),
    site_final_ndci =
      median(annual_ndci),
    .groups = "drop"
  )

# Require at least three valid years
final_result <- all_sites |>
  left_join(
    site_level_core,
    by = "site_id"
  ) |>
  mutate(
    valid_years =
      replace_na(valid_years, 0L),
    
    site_final_ndci = if_else(
      valid_years >= 3,
      site_final_ndci,
      NA_real_
    )
  ) |>
  select(
    site_id,
    valid_years,
    site_final_ndci
  ) |>
  arrange(site_id)

# Save final result only
write_csv(
  final_result,
  "/Users/xinqing/Desktop/B_site_level_NDCI_28sites.csv"
)

print(final_result, n = Inf)

cat("\nSaved: B_site_level_NDCI_28sites.csv\n")