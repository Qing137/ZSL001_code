# ZSL001 - D class
# OSM road-density analysis
# 150 / 500 / 1000 m buffer sensitivity

library(sf)
library(dplyr)
library(stringr)
library(purrr)
library(readr)


# check 28 downloaded road files

road_folder <- path.expand(
  "~/Desktop/ZSL001_D_OSM_ref28"
)

road_files <- list.files(
  road_folder,
  pattern = "_highwa\\.gpkg$",
  full.names = TRUE
)

cat("Number of road files:", length(road_files), "\n")

basename(road_files)


# inspect layers inside all 28 GeoPackages

layer_check <- lapply(road_files, function(f) {
  
  x <- st_layers(f)
  
  data.frame(
    file = basename(f),
    layer = x$name,
    geom_type = x$geomtype,
    stringsAsFactors = FALSE
  )
})

layer_check <- bind_rows(layer_check)

print(layer_check)



# load the three outer-ring shapefiles

ring150_file <- file.choose()
ring500_file <- file.choose()
ring1000_file <- file.choose()

ring150 <- st_read(ring150_file, quiet = TRUE)
ring500 <- st_read(ring500_file, quiet = TRUE)
ring1000 <- st_read(ring1000_file, quiet = TRUE)

cat("ring150 features:", nrow(ring150), "\n")
cat("ring500 features:", nrow(ring500), "\n")
cat("ring1000 features:", nrow(ring1000), "\n")


# GEE outer-ring exports are WGS84.
# If a shapefile has lost its .prj/CRS metadata, restore the
# EPSG:4326 label without changing the coordinates.
restore_gee_crs <- function(x) {
  
  if (is.na(st_crs(x))) {
    x <- st_set_crs(x, 4326)
  }
  
  return(x)
}

ring150 <- restore_gee_crs(ring150)
ring500 <- restore_gee_crs(ring500)
ring1000 <- restore_gee_crs(ring1000)



# repair ring geometries and calculate ring area

prepare_ring <- function(x) {
  
  # Global equal-area projection
  x_proj <- st_transform(x, 6933)
  
  # Repair invalid polygons
  x_proj <- st_make_valid(x_proj)
  
  # Calculate ring area (m2 -> km2)
  x_proj$ring_area_km2 <-
    as.numeric(st_area(x_proj)) / 1e6
  
  # Back to WGS84
  x_fixed <- st_transform(x_proj, 4326)
  
  # Keep only fields needed later
  x_fixed <- x_fixed %>%
    select(
      site_id,
      buffer_m,
      ring_area_km2,
      geometry
    )
  
  return(x_fixed)
}


ring150  <- prepare_ring(ring150)
ring500  <- prepare_ring(ring500)
ring1000 <- prepare_ring(ring1000)


all_rings <- bind_rows(
  ring150,
  ring500,
  ring1000
)


# QA
cat("Total ring rows:", nrow(all_rings), "\n")
cat("Unique sites:", n_distinct(all_rings$site_id), "\n")

print(
  table(all_rings$buffer_m)
)

cat(
  "Invalid geometries remaining:",
  sum(!st_is_valid(all_rings)),
  "\n"
)



# read all 28 OSM road files
# and retain the 10 road classes used for D

tough_classes <- c(
  "primary",
  "secondary",
  "tertiary",
  "unclassified",
  "residential",
  "living_street",
  "service",
  "track",
  "road",
  "construction"
)


read_site_roads <- function(f) {
  
  site_id <- sub(
    "_highwa\\.gpkg$",
    "",
    basename(f)
  )
  
  layer_info <- st_layers(f)
  
  # Find a Line String / Multi Line String layer
  line_idx <- which(
    grepl(
      "Line",
      layer_info$geomtype,
      ignore.case = TRUE
    )
  )
  
  if (length(line_idx) == 0) {
    stop(
      paste("No line layer found for", site_id)
    )
  }
  
  line_layer <- layer_info$name[line_idx[1]]
  
  roads <- st_read(
    f,
    layer = line_layer,
    quiet = TRUE
  )
  
  n_all <- nrow(roads)
  
  # Empty road layer = valid zero-road site
  if (n_all == 0) {
    
    return(
      list(
        site_id = site_id,
        roads = roads,
        n_all = 0,
        n_selected = 0
      )
    )
  }
  
  # Highway field must exist
  if (!"highway" %in% names(roads)) {
    stop(
      paste("No highway field found for", site_id)
    )
  }
  
  # Retain only the 10 selected road classes
  roads_selected <- roads %>%
    filter(
      as.character(highway) %in% tough_classes
    )
  
  return(
    list(
      site_id = site_id,
      roads = roads_selected,
      n_all = n_all,
      n_selected = nrow(roads_selected)
    )
  )
}


road_objects <- lapply(
  road_files,
  read_site_roads
)


roads_by_site <- setNames(
  lapply(
    road_objects,
    function(x) x$roads
  ),
  sapply(
    road_objects,
    function(x) x$site_id
  )
)


road_summary <- bind_rows(
  lapply(
    road_objects,
    function(x) {
      tibble(
        site_id = x$site_id,
        all_highway_features = x$n_all,
        selected_10class_features = x$n_selected
      )
    }
  )
)

road_summary <- road_summary %>%
  arrange(site_id)

cat(
  "Sites successfully read:",
  nrow(road_summary),
  "\n"
)

cat(
  "Sites with zero selected roads:",
  sum(road_summary$selected_10class_features == 0),
  "\n"
)

print(road_summary)



# calculate road density for 28 sites x 3 buffers

get_utm_epsg <- function(x) {
  
  # Use centre of the site's bounding box
  bb <- st_bbox(x)
  
  lon <- mean(c(bb["xmin"], bb["xmax"]))
  lat <- mean(c(bb["ymin"], bb["ymax"]))
  
  zone <- floor((lon + 180) / 6) + 1
  
  if (lat >= 0) {
    epsg <- 32600 + zone
  } else {
    epsg <- 32700 + zone
  }
  
  return(epsg)
}


calculate_one_ring <- function(site, buffer) {
  
  # Get this site's ring
  ring <- all_rings %>%
    filter(
      site_id == site,
      buffer_m == buffer
    )
  
  if (nrow(ring) != 1) {
    stop(
      paste(
        "Expected exactly one ring for",
        site,
        buffer,
        "m"
      )
    )
  }
  
  ring_area <- ring$ring_area_km2[1]
  
  # Get selected 10-class roads
  roads <- roads_by_site[[site]]
  
  # If no selected road exists, road length and density = 0
  if (is.null(roads) || nrow(roads) == 0) {
    
    return(
      tibble(
        site_id = site,
        buffer_m = buffer,
        road_length_km = 0,
        ring_area_km2 = ring_area,
        road_density_km_km2 = 0
      )
    )
  }
  
  
  # Make CRS consistent
  roads <- st_transform(
    roads,
    st_crs(ring)
  )
  
  
  # Use local UTM projection for accurate road length
  utm_epsg <- get_utm_epsg(ring)
  
  ring_utm <- st_transform(
    ring,
    utm_epsg
  )
  
  roads_utm <- st_transform(
    roads,
    utm_epsg
  )
  
  
  # Clip roads exactly to the outer ring
  clipped <- suppressWarnings(
    st_intersection(
      roads_utm,
      st_geometry(ring_utm)
    )
  )
  
  
  # If none of the downloaded roads actually enter this ring
  if (nrow(clipped) == 0) {
    
    road_length <- 0
    
  } else {
    
    road_length <- sum(
      as.numeric(
        st_length(clipped)
      ),
      na.rm = TRUE
    ) / 1000
  }
  
  
  # Road density: km road per km2 outer-ring area
  road_density <- road_length / ring_area
  
  
  tibble(
    site_id = site,
    buffer_m = buffer,
    road_length_km = road_length,
    ring_area_km2 = ring_area,
    road_density_km_km2 = road_density
  )
}



# run all 84 combinations


combos <- st_drop_geometry(all_rings) %>%
  select(site_id, buffer_m) %>%
  distinct() %>%
  arrange(site_id, buffer_m)


D_results_84 <- map2_dfr(
  combos$site_id,
  combos$buffer_m,
  calculate_one_ring
)


# QA
cat(
  "Total D results:",
  nrow(D_results_84),
  "\n"
)

cat(
  "Unique sites:",
  n_distinct(D_results_84$site_id),
  "\n"
)

print(
  table(D_results_84$buffer_m)
)

cat(
  "NA road-density values:",
  sum(is.na(D_results_84$road_density_km_km2)),
  "\n"
)

print(D_results_84)



# export all-buffer results

write_csv(
  D_results_84,
  path.expand("~/Desktop/ZSL001_D_results_ref28_all_buffers.csv")
)



# buffer sensitivity

D150 <- D_results_84 %>%
  filter(buffer_m == 150) %>%
  select(
    site_id,
    RD150 = road_density_km_km2
  )

D500 <- D_results_84 %>%
  filter(buffer_m == 500) %>%
  select(
    site_id,
    RD500 = road_density_km_km2
  )

D1000 <- D_results_84 %>%
  filter(buffer_m == 1000) %>%
  select(
    site_id,
    RD1000 = road_density_km_km2
  )


D_sensitivity <- D150 %>%
  left_join(D500, by = "site_id") %>%
  left_join(D1000, by = "site_id") %>%
  mutate(
    rank150 = rank(-RD150),
    rank500 = rank(-RD500),
    rank1000 = rank(-RD1000),
    max_rank_shift = pmax(
      rank150,
      rank500,
      rank1000
    ) - pmin(
      rank150,
      rank500,
      rank1000
    )
  ) %>%
  arrange(site_id)


# Zero-value counts
cat(
  "Zero values at 150 m:",
  sum(D_sensitivity$RD150 == 0),
  "\n"
)

cat(
  "Zero values at 500 m:",
  sum(D_sensitivity$RD500 == 0),
  "\n"
)

cat(
  "Zero values at 1000 m:",
  sum(D_sensitivity$RD1000 == 0),
  "\n"
)


# Spearman rank correlations
rho_150_500 <- cor(
  D_sensitivity$RD150,
  D_sensitivity$RD500,
  method = "spearman"
)

rho_150_1000 <- cor(
  D_sensitivity$RD150,
  D_sensitivity$RD1000,
  method = "spearman"
)

rho_500_1000 <- cor(
  D_sensitivity$RD500,
  D_sensitivity$RD1000,
  method = "spearman"
)


cat(
  "Spearman 150 vs 500:",
  rho_150_500,
  "\n"
)

cat(
  "Spearman 150 vs 1000:",
  rho_150_1000,
  "\n"
)

cat(
  "Spearman 500 vs 1000:",
  rho_500_1000,
  "\n"
)


# Show sites with largest rank changes
print(
  D_sensitivity %>%
    arrange(desc(max_rank_shift))
)


# Export sensitivity table
write_csv(
  D_sensitivity,
  path.expand("~/Desktop/ZSL001_D_buffer_sensitivity_ref28.csv")
)
