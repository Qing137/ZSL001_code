// ZSL001 — STEP A: Standard sites only (17 sites)
// Runs the JRC occurrence extraction pipeline for the 17 "standard"

var sites = ee.FeatureCollection([
  ee.Feature(ee.Geometry.Point([21.1, 40.767]), {'site_id': 'GRC_MikrPres', 'name': 'Lake Mikri Prespa', 'country': 'Greece'}),
  ee.Feature(ee.Geometry.Point([23.1475, 41.2055]), {'site_id': 'GRC_Kerk', 'name': 'Lake Kerkini', 'country': 'Greece'}),
  ee.Feature(ee.Geometry.Point([21.56472, 40.58981]), {'site_id': 'GRC_Chim', 'name': 'Lake Chimaditis', 'country': 'Greece'}),
  ee.Feature(ee.Geometry.Point([22.822486, 39.492325]), {'site_id': 'GRC_Karl', 'name': 'Lake Karla (Techniti Limni Karla) / Karla Reservoir', 'country': 'Greece'}),
  ee.Feature(ee.Geometry.Point([21.6959, 40.7288]), {'site_id': 'GRC_Petr', 'name': 'Lake Petron', 'country': 'Greece'}),
  ee.Feature(ee.Geometry.Point([67.866433, 55.769208]), {'site_id': 'RUS_BolsBelo', 'name': 'Bolshoe Beloe Lake', 'country': 'Russia'}),
  ee.Feature(ee.Geometry.Point([68.800, 55.650]), {'site_id': 'RUS_TundLake', 'name': 'Tundrovo Lake', 'country': 'Russia'}),
  ee.Feature(ee.Geometry.Point([66.067, 55.550]), {'site_id': 'RUS_ManyLake', 'name': 'Manyass Lake', 'country': 'Russia'}),
  ee.Feature(ee.Geometry.Point([67.998, 55.871]), {'site_id': 'RUS_NyasIn', 'name': 'Nyashino Lake in the Beloozervskii Game Reserve', 'country': 'Russia'}),
  ee.Feature(ee.Geometry.Point([64.4, 54.6]), {'site_id': 'RUS_MalyDonk', 'name': 'Malye Donki Lake', 'country': 'Russia'}),
  ee.Feature(ee.Geometry.Point([51.8, 29.52]), {'site_id': 'IRN_Pari', 'name': 'Lake Parishan', 'country': 'Iran'}),
  ee.Feature(ee.Geometry.Point([49.163, 30.42]), {'site_id': 'IRN_TiffIsla', 'name': 'Tiff Island in Khore Mosa Creek Ramsar site', 'country': 'Iran'}),
  ee.Feature(ee.Geometry.Point([53.082, 30.142]), {'site_id': 'IRN_SivaDam', 'name': 'Sivand Dam lake', 'country': 'Iran'}),
  ee.Feature(ee.Geometry.Point([19.32, 42.17]), {'site_id': 'MNE_Skad', 'name': 'Lake Skadar', 'country': 'Montenegro'}),
  ee.Feature(ee.Geometry.Point([27.96, 40.19]), {'site_id': 'TUR_Many', 'name': 'Lakes Manyas', 'country': 'Turkey'}),
  ee.Feature(ee.Geometry.Point([43.221, 41.215]), {'site_id': 'TUR_Akta', 'name': 'Lake Aktas', 'country': 'Turkey'}),
  ee.Feature(ee.Geometry.Point([29.908430, 38.219316]), {'site_id': 'TUR_Isik', 'name': 'Lake Isiklı', 'country': 'Turkey'}),
]);

print('Total standard sites loaded:', sites.size());

var occurrenceThreshold = 1;
var searchRadiusMeters = 15000;

var searchRadiusOverrides = {
  'MNE_Skad': 30000 // provisional widening; unverified against official boundary
};

var gsw = ee.Image('JRC/GSW1_4/GlobalSurfaceWater');
var occurrence = gsw.select('occurrence');

var waterMask = occurrence.gte(occurrenceThreshold).selfMask();
var connectedCount = waterMask.connectedPixelCount(1000, true);
waterMask = waterMask.updateMask(connectedCount.gte(50));

var siteList = sites.toList(sites.size());
var n = siteList.size().getInfo();

var polygonFeatures = [];

for (var i = 0; i < n; i++) {
  var feature = ee.Feature(siteList.get(i));
  var pt = feature.geometry();
  var siteId = feature.get('site_id');

  var siteIdStr = siteId.getInfo();
  var radiusForThisSite = searchRadiusOverrides[siteIdStr] || searchRadiusMeters;
  var searchArea = pt.buffer(radiusForThisSite);

  var vectors = waterMask.reduceToVectors({
    geometry: searchArea,
    scale: 30,
    geometryType: 'polygon',
    maxPixels: 1e10,
    bestEffort: true
  });

  var vectorCount = vectors.size().getInfo();

  if (vectorCount === 0) {
    print('WARNING: no water polygon found for site ' + siteIdStr +
          ' — check coordinates or lower occurrenceThreshold further.');
    continue;
  }

  var containing = vectors.filterBounds(pt);
  var containingCount = containing.size().getInfo();

  var chosen;
  if (containingCount > 0) {
    var containingWithArea = containing.map(function(f) {
      return f.set('area_m2', f.geometry().area(1));
    });
    chosen = containingWithArea.sort('area_m2', false).first();
  } else {
    print('WARNING: ' + siteIdStr + ' coordinate does not fall inside any ' +
          'extracted water polygon — picking nearest candidate and flagging for review.');
    var withDistance = vectors.map(function(f) {
      return f.set('dist_m', f.geometry().distance(pt, 1));
    });
    chosen = withDistance.sort('dist_m').first();
  }

  var outFeature = ee.Feature(ee.Feature(chosen).geometry(), {
    'site_id': siteIdStr
  });

  polygonFeatures.push(outFeature);
}

var standardPolygons = ee.FeatureCollection(polygonFeatures);

var standardPolygonsWithArea = standardPolygons.map(function(f) {
  var areaKm2 = f.geometry().area(1).divide(1e6);
  return f.set('area_km2', areaKm2);
});

print('Standard site polygons:', standardPolygonsWithArea);

Map.setOptions('SATELLITE');
Map.centerObject(sites, 3);
Map.addLayer(sites, {color: 'red'}, 'Original site points');
Map.addLayer(standardPolygonsWithArea, {color: 'yellow'}, 'Standard site polygons');

// Exports directly to a GEE Asset 
Export.table.toAsset({
  collection: standardPolygonsWithArea,
  description: 'ZSL001_standard_sites_17',
  assetId: 'projects/airrun-494212/assets/ZSL001_standard_sites'
});


Export.table.toDrive({
  collection: standardPolygonsWithArea.map(function(f) {
    return ee.Feature(null, {
      'site_id': f.get('site_id'),
      'area_km2': f.get('area_km2')
    });
  }),
  description: 'ZSL001_standard_sites_areas_17',
  fileNamePrefix: 'ZSL001_standard_sites_areas_17',
  fileFormat: 'CSV'
});