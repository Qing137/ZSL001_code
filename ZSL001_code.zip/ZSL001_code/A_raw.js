// ZSL001 - A1 raw monthly water/coverage export

var standardSites = ee.FeatureCollection('projects/airrun-494212/assets/ZSL001_standard_sites');
var complexSites = ee.FeatureCollection('projects/airrun-494212/assets/ZSL001_complex_sites');
var allSites = standardSites.merge(complexSites);

print('Total sites loaded:', allSites.size());

var breedingWindows = {
  'GRC_MikrPres': [2, 6], 'GRC_Kerk': [2, 6], 'GRC_Chim': [2, 6], 'GRC_Karl': [2, 6],
  'GRC_MessLago': [2, 6], 'GRC_LefkLago': [2, 6], 'GRC_Petr': [2, 6], 'GRC_AmvrWetl': [2, 6],
  'ALB_Kara': [1, 7],
  'RUS_CherLake': [4, 8], 'RUS_BolsBelo': [4, 8], 'RUS_TundLake': [4, 8], 'RUS_ManyLake': [4, 8],
  'RUS_NyasIn': [4, 8], 'RUS_MalyDonk': [4, 8],
  'BGR_SrebLake': [2, 6],
  'IRN_Pari': [3, 7], 'IRN_Bakh': [3, 7], 'IRN_TiffIsla': [2, 6], 'IRN_SivaDam': [3, 7],
  'MNG_AiraLake': [6, 9], 'MNG_KharUs': [6, 9],
  'MNE_Skad': [2, 7],
  'TUR_Many': [1, 7], 'TUR_Akta': [4, 8], 'TUR_Isik': [1, 7],
  'TUR_GediDelt': [2, 7], 'TUR_BuyuMend': [2, 7]
};

var monthlyHistory = ee.ImageCollection('JRC/GSW1_4/MonthlyHistory');

var START_YEAR = 1985;
var END_YEAR = 2021;
var REDUCE_SCALE = 30;
var TILE_SCALE = 4;

// Monthly water fraction and valid coverage

function monthStats(geom, year, month) {
  var monthImg = ee.Image(
    monthlyHistory
      .filter(ee.Filter.calendarRange(year, year, 'year'))
      .filter(ee.Filter.calendarRange(month, month, 'month'))
      .first()
  );

  var validMask = monthImg.select('water').gt(0);
  var waterMask = monthImg.select('water').eq(2);

  var polygonAreaImg = ee.Image.pixelArea();
  var validAreaImg = ee.Image.pixelArea().updateMask(validMask);

  var stats = ee.Image.cat([
    polygonAreaImg.rename('polygon_area'),
    validAreaImg.rename('valid_area'),
    waterMask.updateMask(validMask).rename('water_frac_component')
  ]).reduceRegion({
    reducer: ee.Reducer.sum().combine({
      reducer2: ee.Reducer.mean(),
      sharedInputs: false
    }),
    geometry: geom,
    scale: REDUCE_SCALE,
    maxPixels: 1e10,
    tileScale: TILE_SCALE
  });

  var areaStats = polygonAreaImg.rename('polygon_area')
    .addBands(validAreaImg.rename('valid_area'))
    .reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: geom,
      scale: REDUCE_SCALE,
      maxPixels: 1e10,
      tileScale: TILE_SCALE
    });

  var waterFractionOfValidArea = waterMask
    .updateMask(validMask)
    .rename('f')
    .reduceRegion({
      reducer: ee.Reducer.mean(),
      geometry: geom,
      scale: REDUCE_SCALE,
      maxPixels: 1e10,
      tileScale: TILE_SCALE
    })
    .get('f');

  var polygonArea = areaStats.get('polygon_area');

  var validArea = ee.Algorithms.If(
    areaStats.get('valid_area'),
    areaStats.get('valid_area'),
    0
  );

  var validCoverageFraction = ee.Number(validArea)
    .divide(ee.Number(polygonArea));

  return ee.Feature(null, {
    'year': year,
    'month': month,
    'water_fraction_of_valid_area': waterFractionOfValidArea,
    'valid_coverage_fraction': validCoverageFraction
  });
}

// Build breeding-season monthly table for each site

function buildSiteTable(geom, siteIdStr, startMonth, endMonth) {
  var years = ee.List.sequence(START_YEAR, END_YEAR);
  var months = ee.List.sequence(startMonth, endMonth);

  var yearMonthPairs = years.map(function(y) {
    return months.map(function(m) {
      return ee.List([y, m]);
    });
  }).flatten();

  var features = years.map(function(y) {
    return months.map(function(m) {
      return monthStats(
        geom,
        ee.Number(y),
        ee.Number(m)
      ).set('site_id', siteIdStr);
    });
  }).flatten();

  return ee.FeatureCollection(features);
}

// Create one export task per site

var siteList = allSites.toList(allSites.size());
var n = siteList.size().getInfo();

for (var i = 0; i < n; i++) {
  var feature = ee.Feature(siteList.get(i));
  var siteIdStr = feature.get('site_id').getInfo();
  var geom = feature.geometry();

  var window = breedingWindows[siteIdStr];

  if (!window) {
    print('WARNING: no breeding window defined for ' + siteIdStr + ' - skipping.');
    continue;
  }

  var startMonth = window[0];
  var endMonth = window[1];

  var siteTable = buildSiteTable(
    geom,
    siteIdStr,
    startMonth,
    endMonth
  );

  Export.table.toDrive({
    collection: siteTable,
    description: 'ZSL001_A1_raw_' + siteIdStr,
    fileNamePrefix: 'ZSL001_A1_raw_' + siteIdStr,
    fileFormat: 'CSV',
    selectors: [
      'site_id',
      'year',
      'month',
      'water_fraction_of_valid_area',
      'valid_coverage_fraction'
    ]
  });
}

print('Created ' + n + ' export tasks.');