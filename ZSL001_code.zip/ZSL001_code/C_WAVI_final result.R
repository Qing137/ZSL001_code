# ZSL001 C class
# 28 reference sites: final site-level WAVI

library(tidyverse)

input_dir <- path.expand("~/Desktop/WAVI")

reference_sites <- c(
  "GRC_MikrPres",
  "GRC_Kerk",
  "GRC_Chim",
  "GRC_Karl",
  "GRC_MessLago",
  "GRC_LefkLago",
  "GRC_Petr",
  "GRC_AmvrWetl",
  "ALB_Kara",
  "RUS_CherLake",
  "RUS_BolsBelo",
  "RUS_TundLake",
  "RUS_ManyLake",
  "RUS_NyasIn",
  "RUS_MalyDonk",
  "BGR_SrebLake",
  "IRN_Pari",
  "IRN_Bakh",
  "IRN_TiffIsla",
  "IRN_SivaDam",
  "MNG_AiraLake",
  "MNG_KharUs",
  "MNE_Skad",
  "TUR_Many",
  "TUR_Akta",
  "TUR_Isik",
  "TUR_GediDelt",
  "TUR_BuyuMend"
)

# Read all C monthly CSVs
files <- list.files(
  input_dir,
  pattern = "monthly_diagnostic_.*\\.csv$",
  full.names = TRUE
)

all_data <- map_dfr(
  files,
  ~ read_csv(
    .x,
    show_col_types = FALSE,
    na = c("", "NA", "NaN")
  )
) %>%
  filter(site_id %in% reference_sites)

# Check 28 reference sites
if (n_distinct(all_data$site_id) != 28) {
  stop("The dataset does not contain exactly 28 reference sites.")
}

# Check duplicate site-year-month records
duplicate_rows <- all_data %>%
  count(site_id, year, month) %>%
  filter(n > 1)

if (nrow(duplicate_rows) > 0) {
  print(duplicate_rows, n = Inf)
  stop("Duplicate site-year-month records were found.")
}

# Monthly -> annual median
annual_data <- all_data %>%
  group_by(site_id, year) %>%
  summarise(
    annual_wavi = if (
      all(is.na(monthly_wavi_median))
    ) {
      NA_real_
    } else {
      median(
        monthly_wavi_median,
        na.rm = TRUE
      )
    },
    .groups = "drop"
  )

# Annual -> final site median
final_result <- annual_data %>%
  group_by(site_id) %>%
  summarise(
    site_final_wavi = if (
      all(is.na(annual_wavi))
    ) {
      NA_real_
    } else {
      median(
        annual_wavi,
        na.rm = TRUE
      )
    },
    .groups = "drop"
  ) %>%
  arrange(site_id)

# Save final result only
write_csv(
  final_result,
  file.path(
    input_dir,
    "C_site_level_WAVI_28sites.csv"
  )
)

print(final_result, n = Inf)

cat("\nSaved: ZSL001_C_site_level_WAVI_28sites.csv\n")