# ZSL001 - D class
# Download OSM roads for UK candidate sites

import os
import time
import processing

from qgis.core import (
    QgsProject,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform
)


# settings

layer_name = 'ZSL001_D_ring500_UK9'

output_folder = os.path.join(
    os.path.expanduser('~'),
    'Desktop',
    'D UK',
    'OSM'
)

os.makedirs(
    output_folder,
    exist_ok=True
)

algorithm = 'quickosm:downloadosmdataextentquery'

server = 'https://overpass-api.de/api/interpreter'

timeout_seconds = 180

max_attempts = 4


# find ring layer

layers = QgsProject.instance().mapLayersByName(layer_name)

if len(layers) == 0:
    raise Exception('Cannot find layer: ' + layer_name)

ring_layer = layers[0]

print('UK ring features:', ring_layer.featureCount())


# set target CRS

target_crs = QgsCoordinateReferenceSystem('EPSG:4326')

transform = QgsCoordinateTransform(
    ring_layer.crs(),
    target_crs,
    QgsProject.instance()
)


# create feature dictionary

feature_dict = {
    str(f['site_id']): f
    for f in ring_layer.getFeatures()
}

site_ids = sorted(feature_dict.keys())

print('UK sites to process:', len(site_ids))
print(site_ids)


# download OSM highway data

for i, site_id in enumerate(site_ids, start=1):

    print('')
    print(f'[{i}/{len(site_ids)}] Processing {site_id}')

    feature = feature_dict[site_id]

    geom = feature.geometry()

    if ring_layer.crs() != target_crs:
        geom.transform(transform)

    extent = geom.boundingBox()

    final_gpkg = os.path.join(
        output_folder,
        f'{site_id}_highwa.gpkg'
    )

    success = False


    for attempt in range(1, max_attempts + 1):

        print(f'Attempt {attempt}/{max_attempts}')

        try:

            result = processing.run(
                algorithm,
                {
                    'KEY': 'highway',
                    'VALUE': '',
                    'TYPE_MULTI_REQUEST': '',
                    'EXTENT': extent,
                    'TIMEOUT': timeout_seconds,
                    'SERVER': server,
                    'FILE': 'TEMPORARY_OUTPUT'
                }
            )

            road_lines = result['OUTPUT_LINES']

            # save line layer to GPKG

            processing.run(
                'native:savefeatures',
                {
                    'INPUT': road_lines,
                    'OUTPUT': final_gpkg
                }
            )

            print('SUCCESS:', site_id)
            print('Saved:')
            print(final_gpkg)

            success = True
            break

        except Exception as e:

            print('FAILED:', site_id)
            print(str(e))

            if attempt < max_attempts:

                wait_seconds = 60 * attempt

                print(
                    f'Waiting {wait_seconds} seconds before retry...'
                )

                time.sleep(wait_seconds)


    if not success:

        print('FINAL FAILURE:', site_id)


    if i < len(site_ids):

        print('Waiting 20 seconds before next site...')
        time.sleep(20)


print('')
print('UK OSM download finished')