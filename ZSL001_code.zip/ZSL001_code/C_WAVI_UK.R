# ZSL001 C class
# UK 8 candidate sites: final site-level WAVI

library(tidyverse)

input_dir <- path.expand("~/Desktop/WAVI UK")

reference_sites <- c(
  "UK_Abberton",
  "UK_Ranworth",
  "UK_Hickling",
  "UK_Horsey",
  "UK_ChewValley",
  "UK_HamWall",
  "UK_Shapwick",
  "UK_Minsmere"
)

# Read all C monthly CSVs
files <- list.files(
  input_dir,
  pattern = "monthly_diagnostic_.*\\.csv$",
  full.names = TRUE
)

all_data <- map_dfr(
  files,
  ~ read_csv(
    .x,
    show_col_types = FALSE,
    na = c("", "NA", "NaN")
  )
) %>%
  filter(site_id %in% reference_sites)

# Check 8 UK sites
if (n_distinct(all_data$site_id) != 8) {
  stop("The dataset does not contain exactly 8 UK sites.")
}

# Check duplicate site-year-month records
duplicate_rows <- all_data %>%
  count(site_id, year, month) %>%
  filter(n > 1)

if (nrow(duplicate_rows) > 0) {
  print(duplicate_rows, n = Inf)
  stop("Duplicate site-year-month records were found.")
}

# Monthly -> annual median
annual_data <- all_data %>%
  group_by(site_id, year) %>%
  summarise(
    annual_wavi = if (
      all(is.na(monthly_wavi_median))
    ) {
      NA_real_
    } else {
      median(
        monthly_wavi_median,
        na.rm = TRUE
      )
    },
    .groups = "drop"
  )

# Annual -> final site median
final_result <- annual_data %>%
  group_by(site_id) %>%
  summarise(
    site_final_wavi = if (
      all(is.na(annual_wavi))
    ) {
      NA_real_
    } else {
      median(
        annual_wavi,
        na.rm = TRUE
      )
    },
    .groups = "drop"
  ) %>%
  arrange(site_id)

# Save final result only
write_csv(
  final_result,
  file.path(
    input_dir,
    "C_site_level_WAVI_UK8.csv"
  )
)

print(final_result, n = Inf)

cat("\nSaved: C_site_level_WAVI_UK8.csv\n")