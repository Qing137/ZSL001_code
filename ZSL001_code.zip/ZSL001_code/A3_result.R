# A3-class: long-term breeding-season open-water trend (Mann-Kendall + Sen's slope)
# Requires the `Kendall` package (install.packages("Kendall")).

library(tidyverse)
library(Kendall)

csv_files <- list.files(
  path = "~/Desktop/A all",
  pattern = "^ZSL001_A1_raw_.*\\.csv$",
  full.names = TRUE
)
stopifnot(length(csv_files) == 28)

all_data <- csv_files |> map_dfr(read_csv, show_col_types = FALSE)
stopifnot(n_distinct(all_data$site_id) == 28)

duplicate_rows <- all_data |> count(site_id, year, month) |> filter(n > 1)
stopifnot(nrow(duplicate_rows) == 0)

all_data_final <- all_data |>
  filter(
    !(site_id == "GRC_Karl" & year < 2011),
    !(site_id == "IRN_SivaDam" & year < 2008)
  )

site_window_lengths <- all_data_final |>
  group_by(site_id) |>
  summarise(expected_breeding_months = n_distinct(month), .groups = "drop")

valid_months <- all_data_final |>
  filter(valid_coverage_fraction >= 0.70, !is.na(water_fraction_of_valid_area))

annual_series <- valid_months |>
  group_by(site_id, year) |>
  summarise(
    valid_month_count = n(),
    annual_mean_water_fraction = mean(water_fraction_of_valid_area, na.rm = TRUE),
    .groups = "drop"
  ) |>
  left_join(site_window_lengths, by = "site_id") |>
  mutate(required_month_count = ceiling(expected_breeding_months * 0.50)) |>
  filter(valid_month_count >= required_month_count) |>
  arrange(site_id, year)

duplicate_years <- annual_series |> count(site_id, year) |> filter(n > 1)
stopifnot(nrow(duplicate_years) == 0)
stopifnot(!anyNA(annual_series$annual_mean_water_fraction))

# Sen's slope uses actual year values, not sequence position
sens_slope <- function(year, value) {
  stopifnot(length(year) == length(value))
  stopifnot(length(year) >= 2)
  stopifnot(length(unique(year)) == length(year))
  
  pairs <- combn(length(year), 2)
  slopes <- (value[pairs[2, ]] - value[pairs[1, ]]) / (year[pairs[2, ]] - year[pairs[1, ]])
  median(slopes, na.rm = TRUE)
}

compute_trend <- function(df) {
  df <- df |> arrange(year)
  mk <- MannKendall(df$annual_mean_water_fraction)
  tibble(
    valid_year_count = nrow(df),
    first_valid_year = min(df$year),
    last_valid_year = max(df$year),
    MK_tau = as.numeric(mk$tau),
    MK_p_value = as.numeric(mk$sl),
    sens_slope_per_year = sens_slope(df$year, df$annual_mean_water_fraction)
  )
}

final_A3_results <- annual_series |>
  group_by(site_id) |>
  group_modify(~ compute_trend(.x)) |>
  ungroup() |>
  mutate(
    A3_abs_sen_slope = abs(sens_slope_per_year),
    MK_adjusted_p_value = p.adjust(MK_p_value, method = "BH"),
    trend_direction = case_when(
      MK_adjusted_p_value >= 0.05 ~ "No significant trend",
      MK_tau > 0 ~ "Significant increase",
      MK_tau < 0 ~ "Significant decline",
      TRUE ~ "No significant trend"
    )
  ) |>
  arrange(site_id)

print(final_A3_results, n = 28, width = Inf)
stopifnot(n_distinct(final_A3_results$site_id) == 28)

write_csv(
  final_A3_results,
  "~/Desktop/A all/A3_results.csv"
)