# ZSL001 - D class
# Final 500 m road-density result and reference baseline


library(dplyr)
library(readr)


# load the three-buffer result
# Select the CSV containing the 28 sites x 3 buffers
D_results_84 <- read_csv(
  file.choose(),
  show_col_types = FALSE
)



# extract the final 500 m result


D_final_500 <- D_results_84 %>%
  filter(buffer_m == 500) %>%
  arrange(site_id)


# QA

cat(
  "Final 500 m rows:",
  nrow(D_final_500),
  "\n"
)

cat(
  "Unique sites:",
  n_distinct(D_final_500$site_id),
  "\n"
)

cat(
  "NA road-density values:",
  sum(is.na(D_final_500$road_density_km_km2)),
  "\n"
)

cat(
  "Zero road-density sites:",
  sum(D_final_500$road_density_km_km2 == 0),
  "\n"
)

print(D_final_500)



# export final 500 m CSV

write_csv(
  D_final_500,
  path.expand("~/Desktop/ZSL001_D_final_ref28_500m.csv")
)



# calculate reference baseline
# Median + 25th percentile + 75th percentile


D_baseline <- D_final_500 %>%
  summarise(
    median = median(
      road_density_km_km2,
      na.rm = TRUE
    ),
    Q25 = quantile(
      road_density_km_km2,
      0.25,
      na.rm = TRUE
    ),
    Q75 = quantile(
      road_density_km_km2,
      0.75,
      na.rm = TRUE
    )
  )

print(D_baseline)
