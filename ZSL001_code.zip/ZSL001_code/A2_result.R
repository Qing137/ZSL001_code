# A2-class: within-season breeding-season open-water range

library(tidyverse)

csv_files <- list.files(
  path = "~/Desktop/A all",
  pattern = "^ZSL001_A1_raw_.*\\.csv$",
  full.names = TRUE
)
stopifnot(length(csv_files) == 28)

all_data <- csv_files |> map_dfr(read_csv, show_col_types = FALSE)
stopifnot(n_distinct(all_data$site_id) == 28)

duplicate_rows <- all_data |> count(site_id, year, month) |> filter(n > 1)
stopifnot(nrow(duplicate_rows) == 0)

all_data_final <- all_data |>
  filter(
    !(site_id == "GRC_Karl" & year < 2011),
    !(site_id == "IRN_SivaDam" & year < 2008)
  )

site_window_lengths <- all_data_final |>
  group_by(site_id) |>
  summarise(expected_breeding_months = n_distinct(month), .groups = "drop")

valid_months <- all_data_final |>
  filter(valid_coverage_fraction >= 0.70, !is.na(water_fraction_of_valid_area))

annual_series <- valid_months |>
  group_by(site_id, year) |>
  summarise(
    valid_month_count = n(),
    annual_min_water_fraction = min(water_fraction_of_valid_area, na.rm = TRUE),
    annual_max_water_fraction = max(water_fraction_of_valid_area, na.rm = TRUE),
    annual_water_extent_range = annual_max_water_fraction - annual_min_water_fraction,
    .groups = "drop"
  ) |>
  left_join(site_window_lengths, by = "site_id") |>
  mutate(required_month_count = ceiling(expected_breeding_months * 0.50)) |>
  filter(valid_month_count >= required_month_count) |>
  arrange(site_id, year)

duplicate_years <- annual_series |> count(site_id, year) |> filter(n > 1)
stopifnot(nrow(duplicate_years) == 0)
stopifnot(!anyNA(annual_series$annual_water_extent_range))

final_A2_results <- annual_series |>
  group_by(site_id) |>
  summarise(
    valid_year_count = n(),
    first_valid_year = min(year),
    last_valid_year = max(year),
    A2_median_water_extent_range = median(annual_water_extent_range, na.rm = TRUE),
    .groups = "drop"
  ) |>
  arrange(site_id)

print(final_A2_results, n = 28, width = Inf)
stopifnot(n_distinct(final_A2_results$site_id) == 28)

write_csv(
  final_A2_results,
  "~/Desktop/A all/A2_results.csv"
)