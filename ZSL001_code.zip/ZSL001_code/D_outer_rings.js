// ZSL001 - D class
// Create 150 / 500 / 1000 m OUTER RINGS

var standardSites = ee.FeatureCollection(
  'projects/airrun-494212/assets/ZSL001_standard_sites'
);

var complexSites = ee.FeatureCollection(
  'projects/airrun-494212/assets/ZSL001_complex_sites'
);


var allSites = standardSites.merge(complexSites);

print('Standard sites:', standardSites.size());
print('Complex sites:', complexSites.size());
print('All sites before exclusion:', allSites.size());



var referenceSites = allSites
  .filter(ee.Filter.neq('site_id', 'ROU_DanuDelt'))
  .sort('site_id');

print('Final reference sites:', referenceSites.size());

print(
  'Final site IDs:',
  referenceSites.aggregate_array('site_id')
);



function makeOuterRing(fc, distance) {

  return fc.map(function(feature) {

    var original = feature.geometry();

    // Full buffer around wetland
    var buffered = original.buffer(distance);

    // Remove original wetland polygon
    // => surrounding outer ring only
    var ring = buffered.difference(original);

    // Ring area:
    // Earth Engine area() returns m2
    // divide by 1e6 => km2
    var ringAreaKm2 = ring
      .area(1)
      .divide(1e6);

    // Create a clean output feature.
    // Do NOT keep the old area_km2 field because that referred
    // to the original wetland, not the new ring.
    return ee.Feature(ring, {
      site_id: feature.get('site_id'),
      buffer_m: distance,
      ring_area_km2: ringAreaKm2
    });

  }).sort('site_id');
}



var ring150 = makeOuterRing(referenceSites, 150);
var ring500 = makeOuterRing(referenceSites, 500);
var ring1000 = makeOuterRing(referenceSites, 1000);



print('----------------------------------');
print('CHECK OUTER RINGS');
print('----------------------------------');

print('150 m ring count:', ring150.size());
print('500 m ring count:', ring500.size());
print('1000 m ring count:', ring1000.size());




print('Example 150 m ring:', ring150.first());
print('Example 500 m ring:', ring500.first());
print('Example 1000 m ring:', ring1000.first());




print(
  '150 m ring areas:',
  ring150.aggregate_array('ring_area_km2')
);

print(
  '500 m ring areas:',
  ring500.aggregate_array('ring_area_km2')
);

print(
  '1000 m ring areas:',
  ring1000.aggregate_array('ring_area_km2')
);



// Original wetlands
Map.addLayer(
  referenceSites,
  {color: 'FFFF00'},
  'Original 28 polygons',
  true
);

// 150 m outer rings
Map.addLayer(
  ring150,
  {color: '00FFFF'},
  '150 m OUTER RINGS',
  false
);

// 500 m outer rings
Map.addLayer(
  ring500,
  {color: 'FFA500'},
  '500 m OUTER RINGS',
  true
);

// 1000 m outer rings
Map.addLayer(
  ring1000,
  {color: 'FF0000'},
  '1000 m OUTER RINGS',
  false
);

Map.centerObject(referenceSites, 3);



Export.table.toDrive({
  collection: ring150,
  description: 'ZSL001_D_ring150_ref28',
  folder: 'ZSL001_D',
  fileNamePrefix: 'ZSL001_D_ring150_ref28',
  fileFormat: 'SHP'
});



Export.table.toDrive({
  collection: ring500,
  description: 'ZSL001_D_ring500_ref28',
  folder: 'ZSL001_D',
  fileNamePrefix: 'ZSL001_D_ring500_ref28',
  fileFormat: 'SHP'
});



Export.table.toDrive({
  collection: ring1000,
  description: 'ZSL001_D_ring1000_ref28',
  folder: 'ZSL001_D',
  fileNamePrefix: 'ZSL001_D_ring1000_ref28',
  fileFormat: 'SHP'
});