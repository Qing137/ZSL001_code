# ZSL001 - D class
# Final 500 m road-density results for UK candidate sites


library(sf)
library(dplyr)
library(stringr)
library(purrr)
library(readr)


# check downloaded UK road files

road_folder <- path.expand(
  "~/Desktop/D UK/OSM"
)

road_files <- list.files(
  road_folder,
  pattern = "_highwa\\.gpkg$",
  full.names = TRUE
)

cat("Number of road files:", length(road_files), "\n")

basename(road_files)


# inspect layers inside all GeoPackages

layer_check <- lapply(road_files, function(f) {
  
  x <- st_layers(f)
  
  data.frame(
    file = basename(f),
    layer = x$name,
    geom_type = x$geomtype,
    stringsAsFactors = FALSE
  )
})

layer_check <- bind_rows(layer_check)

print(layer_check)


# load UK 500 m outer ring shapefile

ring500_file <- file.choose()

ring500 <- st_read(
  ring500_file,
  quiet = TRUE
)

cat(
  "500 m ring features:",
  nrow(ring500),
  "\n"
)


# restore GEE CRS if needed

restore_gee_crs <- function(x) {
  
  if (is.na(st_crs(x))) {
    x <- st_set_crs(x, 4326)
  }
  
  return(x)
}

ring500 <- restore_gee_crs(ring500)


# repair ring geometries and calculate ring area

prepare_ring <- function(x) {
  
  x_proj <- st_transform(x, 6933)
  
  x_proj <- st_make_valid(x_proj)
  
  x_proj$ring_area_km2 <-
    as.numeric(st_area(x_proj)) / 1e6
  
  x_fixed <- st_transform(x_proj, 4326)
  
  x_fixed <- x_fixed %>%
    select(
      site_id,
      buffer_m,
      ring_area_km2,
      geometry
    )
  
  return(x_fixed)
}

ring500 <- prepare_ring(ring500)


# QA

cat(
  "Unique UK sites:",
  n_distinct(ring500$site_id),
  "\n"
)

cat(
  "Invalid geometries remaining:",
  sum(!st_is_valid(ring500)),
  "\n"
)


# retain the same 10 road classes used for reference sites

tough_classes <- c(
  "primary",
  "secondary",
  "tertiary",
  "unclassified",
  "residential",
  "living_street",
  "service",
  "track",
  "road",
  "construction"
)


read_site_roads <- function(f) {
  
  site_id <- sub(
    "_highwa\\.gpkg$",
    "",
    basename(f)
  )
  
  layer_info <- st_layers(f)
  
  line_idx <- which(
    grepl(
      "Line",
      layer_info$geomtype,
      ignore.case = TRUE
    )
  )
  
  if (length(line_idx) == 0) {
    stop(
      paste("No line layer found for", site_id)
    )
  }
  
  line_layer <- layer_info$name[line_idx[1]]
  
  roads <- st_read(
    f,
    layer = line_layer,
    quiet = TRUE
  )
  
  n_all <- nrow(roads)
  
  if (n_all == 0) {
    
    return(
      list(
        site_id = site_id,
        roads = roads,
        n_all = 0,
        n_selected = 0
      )
    )
  }
  
  if (!"highway" %in% names(roads)) {
    stop(
      paste("No highway field found for", site_id)
    )
  }
  
  roads_selected <- roads %>%
    filter(
      as.character(highway) %in% tough_classes
    )
  
  return(
    list(
      site_id = site_id,
      roads = roads_selected,
      n_all = n_all,
      n_selected = nrow(roads_selected)
    )
  )
}


road_objects <- lapply(
  road_files,
  read_site_roads
)


roads_by_site <- setNames(
  lapply(
    road_objects,
    function(x) x$roads
  ),
  sapply(
    road_objects,
    function(x) x$site_id
  )
)


road_summary <- bind_rows(
  lapply(
    road_objects,
    function(x) {
      tibble(
        site_id = x$site_id,
        all_highway_features = x$n_all,
        selected_10class_features = x$n_selected
      )
    }
  )
)

road_summary <- road_summary %>%
  arrange(site_id)

cat(
  "Sites successfully read:",
  nrow(road_summary),
  "\n"
)

cat(
  "Sites with zero selected roads:",
  sum(road_summary$selected_10class_features == 0),
  "\n"
)

print(road_summary)


# calculate road density

get_utm_epsg <- function(x) {
  
  bb <- st_bbox(x)
  
  lon <- mean(c(bb["xmin"], bb["xmax"]))
  lat <- mean(c(bb["ymin"], bb["ymax"]))
  
  zone <- floor((lon + 180) / 6) + 1
  
  if (lat >= 0) {
    epsg <- 32600 + zone
  } else {
    epsg <- 32700 + zone
  }
  
  return(epsg)
}


calculate_one_site <- function(site) {
  
  ring <- ring500 %>%
    filter(
      site_id == site
    )
  
  if (nrow(ring) != 1) {
    stop(
      paste(
        "Expected exactly one ring for",
        site
      )
    )
  }
  
  ring_area <- ring$ring_area_km2[1]
  
  roads <- roads_by_site[[site]]
  
  if (is.null(roads) || nrow(roads) == 0) {
    
    return(
      tibble(
        site_id = site,
        buffer_m = 500,
        road_length_km = 0,
        ring_area_km2 = ring_area,
        road_density_km_km2 = 0
      )
    )
  }
  
  roads <- st_transform(
    roads,
    st_crs(ring)
  )
  
  utm_epsg <- get_utm_epsg(ring)
  
  ring_utm <- st_transform(
    ring,
    utm_epsg
  )
  
  roads_utm <- st_transform(
    roads,
    utm_epsg
  )
  
  clipped <- suppressWarnings(
    st_intersection(
      roads_utm,
      st_geometry(ring_utm)
    )
  )
  
  if (nrow(clipped) == 0) {
    
    road_length <- 0
    
  } else {
    
    road_length <- sum(
      as.numeric(
        st_length(clipped)
      ),
      na.rm = TRUE
    ) / 1000
  }
  
  road_density <- road_length / ring_area
  
  tibble(
    site_id = site,
    buffer_m = 500,
    road_length_km = road_length,
    ring_area_km2 = ring_area,
    road_density_km_km2 = road_density
  )
}


# run all UK sites

site_ids <- sort(
  unique(ring500$site_id)
)

D_UK_final_500 <- map_dfr(
  site_ids,
  calculate_one_site
)


# QA

cat(
  "Final 500 m rows:",
  nrow(D_UK_final_500),
  "\n"
)

cat(
  "Unique sites:",
  n_distinct(D_UK_final_500$site_id),
  "\n"
)

cat(
  "NA road-density values:",
  sum(is.na(D_UK_final_500$road_density_km_km2)),
  "\n"
)

cat(
  "Zero road-density sites:",
  sum(D_UK_final_500$road_density_km_km2 == 0),
  "\n"
)

print(D_UK_final_500)


# export final UK 500 m CSV

write_csv(
  D_UK_final_500,
  path.expand("~/Desktop/D UK/ZSL001_D_final_UK_500m.csv")
)