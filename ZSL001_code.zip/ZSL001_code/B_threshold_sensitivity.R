# ZSL001 — B threshold sensitivity analysis

b_zip <- file.choose()

temp_dir <- tempfile()

dir.create(temp_dir)

unzip(
  b_zip,
  exdir = temp_dir
)

b_files <- list.files(
  temp_dir,
  pattern = "^ZSL001_B_monthly_diagnostic_.*\\.csv$",
  full.names = TRUE,
  recursive = TRUE
)

length(b_files)

b_data <- map_dfr(
  b_files,
  read_csv,
  show_col_types = FALSE
)

b_data |>
  summarise(
    sites = n_distinct(site_id),
    rows = n()
  )

# Fixed monthly QC
valid_months <- b_data |>
  filter(
    status == "OK",
    !is.na(monthly_ndci_median)
  )

annual_month_fraction_thresholds <- c(0.5, 0.6, 0.7, 0.8)

# Determine the expected number of breeding-window months for each site
site_window_lengths <- b_data |>
  group_by(site_id) |>
  summarise(
    expected_months = n_distinct(month),
    .groups = "drop"
  )

threshold_results <- map_dfr(
  annual_month_fraction_thresholds,
  function(current_threshold) {
    
    annual_results <- valid_months |>
      group_by(site_id, year) |>
      summarise(
        valid_month_count = n(),
        annual_ndci =
          median(monthly_ndci_median),
        .groups = "drop"
      ) |>
      left_join(
        site_window_lengths,
        by = "site_id"
      ) |>
      mutate(
        required_month_count =
          ceiling(expected_months * current_threshold)
      ) |>
      filter(
        valid_month_count >= required_month_count
      )
    
    annual_results |>
      group_by(site_id) |>
      summarise(
        valid_year_count = n(),
        .groups = "drop"
      ) |>
      mutate(
        annual_month_fraction =
          current_threshold
      )
  }
)

View(threshold_results)

threshold_summary <- threshold_results |>
  group_by(annual_month_fraction) |>
  summarise(
    sites_retained = n_distinct(site_id),
    median_valid_years = median(valid_year_count),
    minimum_valid_years = min(valid_year_count),
    maximum_valid_years = max(valid_year_count),
    sites_with_3_or_more_years =
      sum(valid_year_count >= 3),
    sites_with_5_or_more_years =
      sum(valid_year_count >= 5),
    .groups = "drop"
  )

View(threshold_summary)

# Two-level threshold sensitivity analysis

annual_month_fraction_thresholds <- c(0.5, 0.6, 0.7, 0.8)
minimum_valid_years_thresholds <- c(2, 3, 4, 5)

# Test all 16 combinations
two_level_results <- crossing(
  annual_month_fraction = annual_month_fraction_thresholds,
  minimum_valid_years = minimum_valid_years_thresholds
) |>
  pmap_dfr(
    function(annual_month_fraction,
             minimum_valid_years) {
      
      # Calculate annual breeding-season NDCI
      annual_results <- valid_months |>
        group_by(site_id, year) |>
        summarise(
          valid_month_count = n(),
          annual_ndci =
            median(monthly_ndci_median),
          .groups = "drop"
        ) |>
        left_join(
          site_window_lengths,
          by = "site_id"
        ) |>
        mutate(
          required_month_count =
            ceiling(
              expected_months *
                annual_month_fraction
            )
        ) |>
        filter(
          valid_month_count >= required_month_count
        )
      
      # Produce site-level results
      annual_results |>
        group_by(site_id) |>
        summarise(
          valid_year_count = n(),
          site_final_ndci =
            median(annual_ndci),
          .groups = "drop"
        ) |>
        filter(
          valid_year_count >= minimum_valid_years
        ) |>
        mutate(
          annual_month_fraction =
            annual_month_fraction,
          minimum_valid_years =
            minimum_valid_years
        )
    }
  )

View(two_level_results)

two_level_summary <- two_level_results |>
  group_by(
    annual_month_fraction,
    minimum_valid_years
  ) |>
  summarise(
    sites_retained_in_baseline =
      n_distinct(site_id),
    
    median_site_final_ndci =
      median(site_final_ndci),
    
    p25_site_final_ndci =
      quantile(site_final_ndci, 0.25),
    
    p75_site_final_ndci =
      quantile(site_final_ndci, 0.75),
    
    .groups = "drop"
  ) |>
  arrange(
    annual_month_fraction,
    minimum_valid_years
  )

View(two_level_summary)

appendix_threshold_table_B <- two_level_summary |>
  transmute(
    `Required breeding-window months per year (%)` =
      annual_month_fraction * 100,
    
    `Minimum valid years per site` =
      minimum_valid_years,
    
    `Reference sites retained in baseline` =
      sites_retained_in_baseline,
    
    `Median site-level NDCI` =
      round(median_site_final_ndci, 4),
    
    `P25 site-level NDCI` =
      round(p25_site_final_ndci, 4),
    
    `P75 site-level NDCI` =
      round(p75_site_final_ndci, 4)
  )

write_csv(
  appendix_threshold_table_B,
  "/Users/xinqing/Desktop/B all/Appendix_B_threshold_sensitivity.csv"
)

View(appendix_threshold_table_B)